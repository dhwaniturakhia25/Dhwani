jQuery(document).ready(function ($) {
    $(window).scroll(function () {
        if ($(this).scrollTop() > 200) {
            $('body').addClass("header-fixed");
            $('.header-fixed' +
                '' +
                '' +
                '' +
                '').slideDown(1000);
        }
        else {
            $('body').removeClass("header-fixed");
            $('.header-fixed').slideUp(1000);
        }
    });

    $('.mobile-toggle').click(function () {
        $('body').toggleClass("mobile-open");
        // $('.main-menu').slideToggle();
    });

    $('.open').click(function () {
        $(this).next('.sub-menu').toggle();
    });

    $('.data-slide').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        dots: true,
        autoplay: false,
       speed:1500,

    });
});



